from . import algorithms, api, config, dataobjects, geometry, kernel, plots, simpleapi

class UsageService():
    @staticmethod
    def registerFeatureUsage(*args, **kwargs):
        pass
