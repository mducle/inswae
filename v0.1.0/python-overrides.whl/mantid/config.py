class _Instrument():
    def name(self):
        return 'LET'

def getInstrument():
    return _Instrument()
