class OrientedLattice():
    pass
