def legend_set_draggable(*args, **kwargs):
    pass
