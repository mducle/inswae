def show_interface_help(mantidplot_name, assistant_process, area="", collection_file="", qt_url="", external_url= ""):
    pass
