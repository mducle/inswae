m_n = 1.67492749804e-27         # kg (mass of neutron)
neutron_mass = 1.67492749804e-27
hbar = 1.0545718176461565e-34   # J.s (reduced Planck's constant)
e = 1.602176634e-19             # C (charge of electron)
h = 6.62607015e-34              # J.s (Planck's constant)
