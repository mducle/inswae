# Storage location for Mantid files

Downloaded Mantid files required by INSWAE will be stored here.
