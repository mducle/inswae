from collections.abc import Iterable
from mantid.plots import datafunctions, axesfunctions
from mantid.plots.datafunctions import get_normalize_by_bin_width
from mantid.plots.utility import artists_hidden, autoscale_on_update, convert_color_to_hex, legend_set_draggable, MantidAxType