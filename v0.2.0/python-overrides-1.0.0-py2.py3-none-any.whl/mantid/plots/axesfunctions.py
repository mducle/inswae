import collections.abc
import matplotlib
import matplotlib.collections as mcoll
import matplotlib.colors
import matplotlib.dates as mdates
import matplotlib.image as mimage
import numpy
import sys
import mantid.api
import mantid.kernel
import mantid.plots.modest_image
import numpy as np
from mantid.plots.resampling_image import samplingimage
from mantid.plots.datafunctions import get_axes_labels, get_bins, get_distribution, get_matrix_2d_data, get_md_data1d, get_md_data2d_bin_bounds, get_md_data2d_bin_centers, get_normalization, get_sample_log, get_spectrum, get_uneven_data, get_wksp_index_dist_and_label, check_resample_to_regular_grid, get_indices, get_normalize_by_bin_width, get_spectrum_normalisation
from mantid.plots.utility import MantidAxType
from mantid.plots.quad_mesh_wrapper import QuadMeshWrapper
from mantid import logger
_LARGEST, _SMALLEST = (float(sys.maxsize), -sys.maxsize)

def _pcolormesh_nonortho(axes, workspace, nonortho_tr, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    normalization, kwargs = get_normalization(workspace, **kwargs)
    indices, kwargs = get_indices(workspace, **kwargs)
    x, y, z = get_md_data2d_bin_bounds(workspace, indices=indices, normalization=normalization, transpose=transpose)
    X, Y = numpy.meshgrid(x, y)
    xx, yy = nonortho_tr(X, Y)
    _setLabels2D(axes, workspace, indices, transpose)
    axes.grid(False)
    mesh = axes.pcolormesh(xx, yy, z, *args, **kwargs)
    return QuadMeshWrapper(mesh)

def _setLabels1D(axes, workspace, indices=None, normalize_by_bin_width=True, axis=MantidAxType.SPECTRUM):
    labels = get_axes_labels(workspace, indices, normalize_by_bin_width)
    axes.set_xlabel(labels[2 if axis == MantidAxType.BIN else 1])
    axes.set_ylabel(labels[0])

def _setLabels2D(axes, workspace, indices=None, transpose=False, xscale=None, normalize_by_bin_width=True):
    labels = get_axes_labels(workspace, indices, normalize_by_bin_width)
    if transpose:
        axes.set_xlabel(labels[2])
        axes.set_ylabel(labels[1])
    else:
        axes.set_xlabel(labels[1])
        axes.set_ylabel(labels[2])
    axes.colorbar_label = labels[0]
    if xscale is None and hasattr(workspace, 'isCommonLogBins') and workspace.isCommonLogBins():
        axes.set_xscale('log')
    elif xscale is not None:
        axes.set_xscale(xscale)

def _get_data_for_plot(axes, workspace, kwargs, with_dy=False, with_dx=False):
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, dy = get_md_data1d(workspace, normalization, indices)
        if 'wkspIndex' in kwargs:
            kwargs.pop('wkspIndex')
        if 'specNum' in kwargs:
            kwargs.pop('specNum')
        dx = None
        axis = None
    else:
        normalise_spectrum, kwargs = get_spectrum_normalisation(**kwargs)
        axis = MantidAxType(kwargs.pop('axis', MantidAxType.SPECTRUM))
        normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
        workspace_index, distribution, kwargs = get_wksp_index_dist_and_label(workspace, axis, **kwargs)
        if axis == MantidAxType.BIN:
            x, y, dy, dx = get_bins(workspace, workspace_index, with_dy, with_dx)
            vertical_axis = workspace.getAxis(1)
            if isinstance(vertical_axis, mantid.api.NumericAxis):
                axes.set_xlabel(vertical_axis.getUnit().unitID())
                values = vertical_axis.extractValues()
                if isinstance(vertical_axis, mantid.api.BinEdgeAxis):
                    values = (values[0:-1] + values[1:]) / 2.0
                x = [values[i] for i in x]
            if isinstance(vertical_axis, mantid.api.SpectraAxis):
                spectrum_numbers = workspace.getSpectrumNumbers()
                x = [spectrum_numbers[i] for i in x]
        elif axis == MantidAxType.SPECTRUM:
            x, y, dy, dx = get_spectrum(workspace, workspace_index, normalize_by_bin_width, with_dy, with_dx)
        else:
            raise ValueError('Axis {} is not a valid axis number.'.format(axis))
        indices = None
        if normalise_spectrum:
            max_val = numpy.nanmax(y)
            if max_val != 0:
                y = y / max_val
                if dy is not None:
                    dy = dy / max_val
    return (x, y, dy, dx, indices, axis, kwargs)

def _plot_impl(axes, workspace, args, kwargs):
    if 'LogName' in kwargs:
        x, y, FullTime, LogName, units, kwargs = get_sample_log(workspace, **kwargs)
        axes.set_ylabel('{0} ({1})'.format(LogName, units))
        axes.set_xlabel('Time (s)')
        if FullTime:
            axes.xaxis_date()
            axes.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S\n%b-%d'))
            axes.set_xlabel('Time')
        kwargs['drawstyle'] = 'steps-post'
    else:
        normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
        kwargs['normalize_by_bin_width'] = normalize_by_bin_width
        x, y, _, _, indices, axis, kwargs = _get_data_for_plot(axes, workspace, kwargs)
        if kwargs.pop('update_axes_labels', True):
            _setLabels1D(axes, workspace, indices, normalize_by_bin_width=normalize_by_bin_width, axis=axis)
    kwargs.pop('normalize_by_bin_width', None)
    return (x, y, args, kwargs)

def plot(axes, workspace, *args, **kwargs):
    x, y, args, kwargs = _plot_impl(axes, workspace, args, kwargs)
    roi = kwargs.pop('roi', np.zeros(0, dtype=bool))
    if roi.size > 0:
        axes.fill_between(x, min(y), max(y), where=roi, color='grey', alpha=0.5)
    return axes.plot(x, y, *args, **kwargs)

def errorbar(axes, workspace, *args, **kwargs):
    withDy = True
    withDx = False
    if isinstance(workspace, mantid.api.MatrixWorkspace) and workspace.run().hasProperty('plot_type'):
        plot_type = workspace.run().getProperty('plot_type').value
        if plot_type == 'errorbar_x':
            withDy = False
            withDx = True
        if plot_type == 'errorbar_y':
            withDy = True
            withDx = False
        if plot_type == 'errorbar_xy':
            withDy = True
            withDx = True
    normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
    x, y, dy, dx, indices, axis, kwargs = _get_data_for_plot(axes, workspace, kwargs, with_dy=withDy, with_dx=withDx)
    if kwargs.pop('update_axes_labels', True):
        _setLabels1D(axes, workspace, indices, normalize_by_bin_width=normalize_by_bin_width, axis=axis)
    kwargs.pop('normalize_by_bin_width', None)
    if dy is not None and min(dy) < 0:
        dy = None
        logger.warning('Negative values found in y error when plotting error bars. Continuing without y error bars.')
    if dx is not None and min(dx) < 0:
        dx = None
        logger.warning('Negative values found in x error when plotting error bars. Continuing without x error bars.')
    return axes.errorbar(x, y, dy, dx, *args, **kwargs)

def scatter(axes, workspace, *args, **kwargs):
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, _ = get_md_data1d(workspace, normalization, indices)
        _setLabels1D(axes, workspace, indices)
    else:
        wkspIndex, distribution, kwargs = get_wksp_index_dist_and_label(workspace, **kwargs)
        x, y, _, _ = get_spectrum(workspace, wkspIndex, distribution)
        _setLabels1D(axes, workspace)
    return axes.scatter(x, y, *args, **kwargs)

def contour(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, z = get_md_data2d_bin_centers(workspace, normalization, indices, transpose)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        distribution, kwargs = get_distribution(workspace, **kwargs)
        x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=False, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose)
    return axes.contour(x, y, z, *args, **kwargs)

def contourf(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, z = get_md_data2d_bin_centers(workspace, normalization, indices, transpose)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        distribution, kwargs = get_distribution(workspace, **kwargs)
        x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=False, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose)
    return axes.contourf(x, y, z, *args, **kwargs)

def _pcolorpieces(axes, workspace, distribution, *args, **kwargs):
    x, y, z = get_uneven_data(workspace, distribution)
    mini = numpy.min([numpy.min(i) for i in z])
    maxi = numpy.max([numpy.max(i) for i in z])
    if 'vmin' in kwargs:
        mini = kwargs['vmin']
        del kwargs['vmin']
    if 'vmax' in kwargs:
        maxi = kwargs['vmax']
        del kwargs['vmax']
    if 'norm' not in kwargs:
        kwargs['norm'] = matplotlib.colors.Normalize(vmin=mini, vmax=maxi)
    else:
        if kwargs['norm'].vmin is None:
            kwargs['norm'].vmin = mini
        if kwargs['norm'].vmax is None:
            kwargs['norm'].vmax = maxi
    pcolortype = kwargs.pop('pcolortype', '').lower()
    if 'mesh' in pcolortype:
        pcolor = axes.pcolormesh
    elif 'fast' in pcolortype:
        pcolor = axes.pcolorfast
    else:
        pcolor = axes.pcolor
    pieces = []
    for xi, yi, zi in zip(x, y, z):
        XX, YY = numpy.meshgrid(xi, yi, indexing='ij')
        pieces.append(pcolor(XX, YY, zi.reshape(-1, 1), **kwargs))
    return pieces

def pcolor(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, z = get_md_data2d_bin_bounds(workspace, normalization, indices, transpose)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        aligned, kwargs = check_resample_to_regular_grid(workspace, **kwargs)
        normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
        distribution, kwargs = get_distribution(workspace, **kwargs)
        if aligned:
            kwargs['pcolortype'] = ''
            return _pcolorpieces(axes, workspace, distribution, *args, **kwargs)
        else:
            x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=True, transpose=transpose)
            _setLabels2D(axes, workspace, transpose=transpose, normalize_by_bin_width=normalize_by_bin_width)
    return axes.pcolor(x, y, z, *args, **kwargs)

def pcolorfast(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, z = get_md_data2d_bin_bounds(workspace, normalization, indices, transpose)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        aligned, kwargs = check_resample_to_regular_grid(workspace, **kwargs)
        normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
        distribution, kwargs = get_distribution(workspace, **kwargs)
        if aligned:
            kwargs['pcolortype'] = 'fast'
            return _pcolorpieces(axes, workspace, distribution, *args, **kwargs)
        else:
            x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=True, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose, normalize_by_bin_width=normalize_by_bin_width)
    return axes.pcolorfast(x, y, z, *args, **kwargs)

def pcolormesh(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, z = get_md_data2d_bin_bounds(workspace, normalization, indices, transpose)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        aligned, kwargs = check_resample_to_regular_grid(workspace, **kwargs)
        normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
        distribution, kwargs = get_distribution(workspace, **kwargs)
        if aligned:
            kwargs['pcolortype'] = 'mesh'
            return _pcolorpieces(axes, workspace, distribution, *args, **kwargs)
        else:
            x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=True, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose, normalize_by_bin_width=normalize_by_bin_width)
    return axes.pcolormesh(x, y, z, *args, **kwargs)

def imshow(axes, workspace, *args, **kwargs):
    transpose = kwargs.get('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x, y, z = get_md_data2d_bin_bounds(workspace, normalization, indices, transpose)
        _setLabels2D(axes, workspace, indices, transpose)
        if 'extent' not in kwargs:
            if x.ndim == 2 and y.ndim == 2:
                kwargs['extent'] = [x[0, 0], x[0, -1], y[0, 0], y[-1, 0]]
            else:
                kwargs['extent'] = [x[0], x[-1], y[0], y[-1]]
        return mantid.plots.modest_image.imshow(axes, z, *args, **kwargs)
    else:
        aligned, kwargs = check_resample_to_regular_grid(workspace, **kwargs)
        normalize_by_bin_width, kwargs = get_normalize_by_bin_width(workspace, axes, **kwargs)
        kwargs['normalize_by_bin_width'] = normalize_by_bin_width
        _setLabels2D(axes, workspace, transpose=transpose, normalize_by_bin_width=normalize_by_bin_width)
        return samplingimage.imshow_sampling(axes, *args, workspace=workspace, **kwargs)

def tripcolor(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x_temp, y_temp, z = get_md_data2d_bin_centers(workspace, normalization, indices, transpose)
        x, y = numpy.meshgrid(x_temp, y_temp)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        distribution, kwargs = get_distribution(workspace, **kwargs)
        x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=False, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose)
    return axes.tripcolor(x.ravel(), y.ravel(), z.ravel(), *args, **kwargs)

def tricontour(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x_temp, y_temp, z = get_md_data2d_bin_centers(workspace, normalization, indices, transpose)
        x, y = numpy.meshgrid(x_temp, y_temp)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        distribution, kwargs = get_distribution(workspace, **kwargs)
        x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=False, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose)
    x = x.ravel()
    y = y.ravel()
    z = z.ravel()
    condition = numpy.isfinite(z)
    x = x[condition]
    y = y[condition]
    z = z[condition]
    return axes.tricontour(x, y, z, *args, **kwargs)

def tricontourf(axes, workspace, *args, **kwargs):
    transpose = kwargs.pop('transpose', False)
    if isinstance(workspace, mantid.dataobjects.MDHistoWorkspace):
        normalization, kwargs = get_normalization(workspace, **kwargs)
        indices, kwargs = get_indices(workspace, **kwargs)
        x_temp, y_temp, z = get_md_data2d_bin_centers(workspace, normalization, indices, transpose)
        x, y = numpy.meshgrid(x_temp, y_temp)
        _setLabels2D(axes, workspace, indices, transpose)
    else:
        distribution, kwargs = get_distribution(workspace, **kwargs)
        x, y, z = get_matrix_2d_data(workspace, distribution, histogram2D=False, transpose=transpose)
        _setLabels2D(axes, workspace, transpose=transpose)
    x = x.ravel()
    y = y.ravel()
    z = z.ravel()
    condition = numpy.isfinite(z)
    x = x[condition]
    y = y[condition]
    z = z[condition]
    return axes.tricontourf(x, y, z, *args, **kwargs)

def update_colorplot_datalimits(axes, mappables, axis='both'):
    if not isinstance(mappables, collections.abc.Iterable):
        mappables = [mappables]
    xmin_all, xmax_all, ymin_all, ymax_all = (_LARGEST, _SMALLEST, _LARGEST, _SMALLEST)
    for mappable in mappables:
        xmin, xmax, ymin, ymax = get_colorplot_extents(mappable)
        xmin_all, xmax_all = (min(xmin_all, xmin), max(xmax_all, xmax))
        ymin_all, ymax_all = (min(ymin_all, ymin), max(ymax_all, ymax))
    update_x = axis in ['x', 'both']
    update_y = axis in ['y', 'both']
    axes.update_datalim(((xmin_all, ymin_all), (xmax_all, ymax_all)), update_x, update_y)
    axes.autoscale(axis=axis)
    if axes.get_autoscalex_on():
        axes.set_xlim((xmin_all, xmax_all), auto=None)
    if axes.get_autoscaley_on():
        axes.set_ylim((ymin_all, ymax_all), auto=None)

def get_colorplot_extents(mappable):
    if isinstance(mappable, mimage.AxesImage):
        if hasattr(mappable, 'get_full_extent'):
            xmin, xmax, ymin, ymax = mappable.get_full_extent()
        else:
            xmin, xmax, ymin, ymax = mappable.get_extent()
    elif isinstance(mappable, mcoll.QuadMesh):
        coords = mappable._coordinates
        xmin, ymin = coords[0][0]
        xmax, ymax = coords[-1][-1]
    elif isinstance(mappable, mcoll.PolyCollection):
        xmin, ymin = mappable._paths[0].get_extents().min
        xmax, ymax = mappable._paths[-1].get_extents().max
    else:
        raise ValueError("Unknown mappable type '{}'".format(type(mappable)))
    return (xmin, xmax, ymin, ymax)