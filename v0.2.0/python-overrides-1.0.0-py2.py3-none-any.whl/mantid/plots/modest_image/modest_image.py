import numpy as np
import matplotlib
rcParams = matplotlib.rcParams
import matplotlib.image as mi
import matplotlib.colors as mcolors
import matplotlib.cbook as cbook
from matplotlib.transforms import IdentityTransform, Affine2D
from mantid.plots.mantidimage import MantidImage
IDENTITY_TRANSFORM = IdentityTransform()

class ModestImage(MantidImage):

    def __init__(self, *args, **kwargs):
        self._full_res = None
        self.transpose = kwargs.pop('transpose', False)
        self._full_extent = kwargs.get('extent', None)
        super(ModestImage, self).__init__(*args, **kwargs)
        self.invalidate_cache()

    def set_data(self, A):
        self._full_res = A
        self._A = cbook.safe_masked_invalid(A)
        if self._A.dtype != np.uint8 and (not np.can_cast(self._A.dtype, float)):
            raise TypeError('Image data can not convert to float')
        if self._A.ndim not in (2, 3) or (self._A.ndim == 3 and self._A.shape[-1] not in (3, 4)):
            raise TypeError('Invalid dimensions for image data')
        self.invalidate_cache()

    def invalidate_cache(self):
        self._bounds = None
        self._imcache = None
        self._rgbacache = None
        self._oldxslice = None
        self._oldyslice = None
        self._sx, self._sy = (None, None)
        self._pixel2world_cache = None
        self._world2pixel_cache = None

    def set_extent(self, extent):
        self._full_extent = extent
        self.invalidate_cache()
        mi.AxesImage.set_extent(self, extent)

    def get_array(self):
        return self._full_res

    def get_array_clipped_to_bounds(self):
        xlim, ylim = (self.axes.get_xlim(), self.axes.get_ylim())
        transform = self._world2pixel
        ind0 = transform.transform([min(xlim), min(ylim)])
        ind1 = transform.transform([max(xlim), max(ylim)])
        y0 = max(int(np.floor(ind0[1] + 0.5)), 0)
        y1 = max(int(np.floor(ind1[1] + 0.5)) + 1, 0)
        x0 = max(int(np.floor(ind0[0] + 0.5)), 0)
        x1 = max(int(np.floor(ind1[0] + 0.5)) + 1, 0)
        data = self._full_res[y0:y1, x0:x1]
        data = cbook.safe_masked_invalid(data)
        return data

    @property
    def _pixel2world(self):
        if self._pixel2world_cache is None:
            extent = self._full_extent
            if extent is None:
                self._pixel2world_cache = IDENTITY_TRANSFORM
            else:
                self._pixel2world_cache = Affine2D()
                self._pixel2world.translate(+0.5, +0.5)
                self._pixel2world.scale((extent[1] - extent[0]) / self._full_res.shape[1], (extent[3] - extent[2]) / self._full_res.shape[0])
                self._pixel2world.translate(extent[0], extent[2])
            self._world2pixel_cache = None
        return self._pixel2world_cache

    @property
    def _world2pixel(self):
        if self._world2pixel_cache is None:
            self._world2pixel_cache = self._pixel2world.inverted()
        return self._world2pixel_cache

    def _scale_to_res(self):
        x0, x1, sx, y0, y1, sy = extract_matched_slices(axes=self.axes, shape=self._full_res.shape, transform=self._world2pixel)
        if self._bounds is not None and sx >= self._sx and (sy >= self._sy) and (x0 >= self._bounds[0]) and (x1 <= self._bounds[1]) and (y0 >= self._bounds[2]) and (y1 <= self._bounds[3]):
            return
        self._A = self._full_res[y0:y1:sy, x0:x1:sx]
        self._A = cbook.safe_masked_invalid(self._A)
        if self.origin == 'upper' and self._full_extent is None:
            xmin, xmax, ymin, ymax = (x0 - 0.5, x1 - 0.5, y1 - 0.5, y0 - 0.5)
        else:
            xmin, xmax, ymin, ymax = (x0 - 0.5, x1 - 0.5, y0 - 0.5, y1 - 0.5)
        xmin, ymin, xmax, ymax = self._pixel2world.transform([(xmin, ymin), (xmax, ymax)]).ravel()
        mi.AxesImage.set_extent(self, [xmin, xmax, ymin, ymax])
        self._sx = sx
        self._sy = sy
        self._bounds = (x0, x1, y0, y1)
        self.changed()

    def draw(self, renderer, *args, **kwargs):
        if self._full_res.shape is None:
            return
        self._scale_to_res()
        super(ModestImage, self).draw(renderer, *args, **kwargs)

def main():
    from time import time
    import matplotlib.pyplot as plt
    x, y = np.mgrid[0:2000, 0:2000]
    data = np.sin(x / 10.0) * np.cos(y / 30.0)
    f = plt.figure()
    ax = f.add_subplot(111)
    artist = ModestImage(ax, data=data)
    ax.set_aspect('equal')
    artist.norm.vmin = -1
    artist.norm.vmax = 1
    ax.add_artist(artist)
    t0 = time()
    plt.gcf().canvas.draw()
    t1 = time()
    print('Draw time for %s: %0.1f ms' % (artist.__class__.__name__, (t1 - t0) * 1000))
    plt.show()

def imshow(axes, X, cmap=None, norm=None, aspect=None, interpolation=None, alpha=None, vmin=None, vmax=None, origin=None, extent=None, shape=None, filternorm=1, filterrad=4.0, imlim=None, resample=None, url=None, transpose=None, **kwargs):
    if norm is not None:
        assert isinstance(norm, mcolors.Normalize)
    if aspect is None:
        aspect = rcParams['image.aspect']
    axes.set_aspect(aspect)
    im = ModestImage(axes, cmap=cmap, norm=norm, interpolation=interpolation, origin=origin, extent=extent, filternorm=filternorm, filterrad=filterrad, resample=resample, transpose=transpose, **kwargs)
    im.set_data(X)
    im.set_alpha(alpha)
    axes._set_artist_props(im)
    if im.get_clip_path() is None:
        im.set_clip_path(axes.patch)
    if vmin is not None or vmax is not None:
        if norm is not None and isinstance(norm, mcolors.LogNorm):
            if vmin <= 0:
                vmin = 0.0001
            if vmax <= 0:
                vmax = 1
        im.set_clim(vmin, vmax)
    elif norm is None:
        im.autoscale_None()
    im.set_url(url)
    im.set_extent(im.get_extent())
    axes.add_image(im)
    return im

def extract_matched_slices(axes=None, shape=None, extent=None, transform=IDENTITY_TRANSFORM):
    ext = (axes.transAxes.transform([(1, 1)]) - axes.transAxes.transform([(0, 0)]))[0]
    xlim, ylim = (axes.get_xlim(), axes.get_ylim())
    ind0 = transform.transform([min(xlim), min(ylim)])
    ind1 = transform.transform([max(xlim), max(ylim)])

    def _clip(val, lo, hi):
        return int(max(min(val, hi), lo))
    y0 = _clip(ind0[1] - 5, 0, shape[0] - 1)
    y1 = _clip(ind1[1] + 5, 1, shape[0])
    x0 = _clip(ind0[0] - 5, 0, shape[1] - 1)
    x1 = _clip(ind1[0] + 5, 1, shape[1])
    sy = int(max(1, min((y1 - y0) / 5.0, np.ceil(abs((ind1[1] - ind0[1]) / ext[1])))))
    sx = int(max(1, min((x1 - x0) / 5.0, np.ceil(abs((ind1[0] - ind0[0]) / ext[0])))))
    return (x0, x1, sx, y0, y1, sy)
if __name__ == '__main__':
    main()