import numpy as np
from matplotlib.collections import QuadMesh
from matplotlib.cbook import safe_masked_invalid

class QuadMeshWrapper:

    def __init__(self, mesh: QuadMesh):
        self._mesh = mesh

    def __getattr__(self, item):
        return getattr(self._mesh, item)

    def get_array_clipped_to_bounds(self) -> np.ndarray:
        xlim, ylim = (self.axes.get_xlim(), self.axes.get_ylim())
        nedges_y, nedges_x = self._mesh._coordinates.shape[0:2]
        arr = self._mesh.get_array().reshape((nedges_y - 1, nedges_x - 1))
        ydata = self._mesh._coordinates[:-1, 0, 1]
        dy = ydata[1] - ydata[0]
        iy_rows = np.logical_and(ydata >= ylim[0] - dy, ydata < ylim[1])
        if any(iy_rows):
            xdata = self._mesh._coordinates[:-1, :-1, 0][iy_rows, :]
            dx = xdata[0][1] - xdata[0][0]
            xmask = np.logical_and(xdata >= xlim[0] - dx, xdata < xlim[1])
            return safe_masked_invalid(arr[iy_rows, :][xmask])
        else:
            return np.array([], dtype=float)