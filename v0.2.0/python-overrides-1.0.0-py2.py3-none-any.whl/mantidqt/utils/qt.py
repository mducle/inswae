import os.path as osp
from qtpy.uic import loadUi, loadUiType

def load_ui(caller_filename, ui_relfilename, baseinstance=None):
    filepath = osp.join(osp.dirname(caller_filename), ui_relfilename)
    if not osp.exists(filepath):
        raise ImportError('File "{}" does not exist'.format(filepath))
    if not osp.isfile(filepath):
        raise ImportError('File "{}" is not a file'.format(filepath))
    if baseinstance is not None:
        return loadUi(filepath, baseinstance=baseinstance)
    else:
        return loadUiType(filepath)

class QAppThreadCall:

    def __init__(self, callable_, blocking=None):
        self._callable = callable_

    def __call__(self, *args, **kwargs):
        return self._callable(*args, **kwargs)

def force_method_calls_to_qapp_thread(instance, *, all_methods=False):
    return instance
import types, sys
qtc_name = f'{__name__}.qappthreadcall'
qtc_mod = types.ModuleType(qtc_name)
qtc_mod.__dict__['QAppThreadCall'] = QAppThreadCall
qtc_mod.__dict__['force_method_calls_to_qapp_thread'] = force_method_calls_to_qapp_thread
sys.modules[qtc_name] = qtc_mod
from qtpy.QtGui import QDoubleValidator
lev_name = f'{__name__}.line_edit_double_validator'
lev_mod = types.ModuleType(qtc_name)
lev_mod.__dict__['LineEditDoubleValidator'] = QDoubleValidator
sys.modules[lev_name] = lev_mod