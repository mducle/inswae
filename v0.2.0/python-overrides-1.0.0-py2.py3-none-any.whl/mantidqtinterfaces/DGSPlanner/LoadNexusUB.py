import numpy as np
from mantid.simpleapi import LoadEventNexus

def LoadNexusUB(fname):
    raw_workspace = LoadEventNexus(Filename=fname, MetaDataOnly=True, StoreInADS=False)
    run = raw_workspace.getRun()
    run_keys = run.keys()
    UBMatrix_key = [test_key for test_key in run_keys if 'UBMatrix' in test_key][0]
    UB = np.array(eval(run[UBMatrix_key].value[0].strip(')').split('(')[1]))
    return UB