import numpy as np
import collections
import warnings
warnings.simplefilter('always', UserWarning)

def tchop(freq, Ei, pslit, radius, rho):
    p, R, w = tuple([pslit, radius, freq * 2 * np.pi])
    if p == 0.0 and R == 0.0 and (rho == 0.0):
        raise ValueError('PyChop: tchop(): slit width, chopper radius or curvature is zero!')
    veloc = 437.392 * np.sqrt(Ei)
    gamm = 2.0 * R ** 2 / p * abs(1.0 / rho - 2.0 * w / veloc)
    if hasattr(gamm, '__len__'):
        tausqr = np.zeros(len(gamm))
        pre = (p / (2.0 * R * w)) ** 2 / 6.0
        idx = np.where(gamm <= 1.0)
        tausqr[idx] = pre * (1.0 - (gamm[idx] ** 2) ** 2 / 10.0) / (1.0 - gamm[idx] ** 2 / 6.0)
        idx = np.where((gamm > 1.0) * (gamm < 4.0))
        groot = np.sqrt(gamm[idx])
    else:
        if gamm >= 4.0:
            warnings.warn('PyChop: tchop(): No transmission at %5.3f meV at %3d Hz' % (Ei, freq))
            return np.nan
        if gamm <= 1.0:
            gsqr = (1.0 - (gamm ** 2) ** 2 / 10.0) / (1.0 - gamm ** 2 / 6.0)
        else:
            groot = np.sqrt(gamm)
            gsqr = 0.6 * gamm * (groot - 2.0) ** 2 * (groot + 8.0) / (groot + 4.0)
        tausqr = (p / (2.0 * R * w)) ** 2 / 6.0 * gsqr
    return tausqr

def achop(Ei, freq, dslat, pslit, radius, rho):
    _, p1, R1, rho1, w1 = tuple([dslat, pslit, radius, rho, freq * 2 * np.pi])
    vela = 437.392 * np.sqrt(Ei)
    gamm = 2.0 * R1 ** 2 / p1 * abs(1.0 / rho1 - 2.0 * w1 / vela)
    if hasattr(gamm, '__len__'):
        area = np.zeros(len(gamm))
        pre = p1 ** 2 / (2.0 * R1 * w1)
        idx = np.where(gamm <= 1.0)
        area[idx] = pre * (1.0 - gamm[idx] ** 2 / 6.0)
        idx = np.where((gamm > 1.0) * (gamm < 4.0))
        groot = np.sqrt(gamm[idx])
        area[idx] = pre * groot * (groot - 2.0) ** 2 * (groot + 4.0) / 6.0
    else:
        if gamm >= 4.0:
            warnings.warn('PyChop: achop(): No transmission at %5.3f meV at %3d Hz' % (Ei, freq), UserWarning)
            return np.nan
        elif gamm <= 1.0:
            f1 = 1.0 - gamm ** 2 / 6.0
        else:
            groot = np.sqrt(gamm)
            f1 = groot * (groot - 2.0) ** 2 * (groot + 4.0) / 6.0
        area = p1 ** 2 / (2.0 * R1 * w1) * f1
    return area

def tikeda(S1, S2, B1, B2, Emod, Ei):
    Ei = np.array(Ei if hasattr(Ei, '__len__') else [Ei])
    sig = np.sqrt(S1 * S1 + S2 * S2 * 81.8048 / Ei)
    A = 0.000437392 * sig * np.sqrt(Ei)
    tausqr = []
    B = np.array([B1] * len(Ei))
    B[np.where(Ei > 130.0)] = B2
    R = np.exp(-Ei / Emod)
    tausqr = 3.0 / A ** 2 + R * (2.0 - R) / B ** 2
    return (tausqr if len(tausqr) > 1 else tausqr[0]) * 1e-12

def tchi(delta, Ei):
    vel = 437.392 * np.sqrt(Ei)
    tausqr = (delta / 1.96 / vel) ** 2
    return tausqr

def tchi_2(delta_0, delta_G, Ei):
    vel = 437.392 * np.sqrt(Ei)
    tausqr = ((delta_0 + delta_G * np.sqrt(Ei)) / 1.96 / vel) ** 2
    return tausqr

def flux_norm(ch_mod):
    phi0 = {'A': 1.0, 'AP': 2.8, 'H2': 1.8, 'CH4': 2.6}
    if ch_mod not in phi0.keys():
        raise ValueError('Moderator %s is not supported in PyChop' % ch_mod)
    return phi0[ch_mod]

def flux_fun(en_ev, ch_mod):
    if ch_mod == 'A':
        raise ValueError('The "A" Moderator is not supported in PyChop')
    elif ch_mod == 'AP':
        ijoin, rj, t, a, w1, w2, w3, w4, w5 = tuple([0, 2.25, 0.032, 0.95, 120.0, 10.0, 0.0, 0.0, 0.0])
    elif ch_mod == 'H2':
        ijoin, rj, t, a, w1, w2, w3, w4, w5 = tuple([1, 2.35, 0.0021, 0.95, 15.5, 3.1, 11.0, 0.254, 0.0275])
    elif ch_mod == 'CH4':
        ijoin, rj, t, a, w1, w2, w3, w4, w5 = tuple([0, 2.1, 0.011, 0.92, 55.0, 7.0, 0.0, 0.0, 0.0])
    else:
        raise ValueError('Moderator %s is not supported in PyChop' % ch_mod)
    phi_max = rj * (en_ev / t ** 2) * np.exp(-en_ev / t)
    phi_epi = 1.0 / en_ev ** a
    expon = np.exp(-w1 / np.sqrt(1000.0 * en_ev) + w2)
    delt1 = expon / (1.0 + expon)
    if ijoin == 1:
        expon = np.exp((w4 - 1.0 / np.sqrt(1000.0 * en_ev)) / w5)
        delt2 = 1.0 + w3 / (1.0 + expon)
    else:
        delt2 = 1.0
    phifun = phi_max + delt1 * delt2 * phi_epi
    return phifun

def flux_calc(Ei, ch_mod, thetam):
    conv1 = 3.615
    conv2 = 9.104157e-12
    conv = conv1 * conv2
    en_ev = Ei / 1000.0
    phi0 = flux_norm(ch_mod)
    phifun = flux_fun(en_ev, ch_mod)
    flux = conv * (phi0 * np.cos(thetam)) * (np.sqrt(en_ev) * phifun)
    return flux

def detect2(wd, hd, wf, idet, dd):
    if idet == 1:
        raise ValueError('Li detector not supported in Pychop')
    elif idet == 2:
        rad = dd / 2.0
        atms = 10.0
        t2rad = 0.063
        effic, delta, ddsqr, v_dd, v_d = detect_he(wf, rad, atms, t2rad)
        sigd = wd / np.sqrt(12.0)
        sigdz = hd / np.sqrt(12.0)
        sigdd = np.sqrt(v_dd)
    else:
        rad = dd / 2.0
        atms = 10.0
        t2rad = 0.063
        effic, delta, ddsqr, v_dd, v_d = detect_he(wf, rad, atms, t2rad)
        ndet = max(int(wd / dd), 1.0)
        space = 2.0 * rad
        v_d = v_d + space ** 2 * (ndet ** 2 - 1) / 12.0
        sigd = np.sqrt(v_d)
        sigdz = hd / np.sqrt(12.0)
        sigdd = np.sqrt(v_dd)
    return (delta, sigd, sigdz, sigdd, effic)

def detect_he(wvec, rad, atms, t2rad):
    sigref = 143.23
    wref = 3.49416
    atmref = 10.0
    const = sigref * wref / atmref
    if rad < 0.0 or t2rad < 0.0 or t2rad > 1.0 or (atms < 0.0):
        raise ValueError('Error with detect_he input parameters')
    else:
        reff = rad * (1.0 - t2rad)
        var = 2.0 * (rad * (1.0 - t2rad)) * (const * atms)
        if wvec < var * 1e-18:
            raise ValueError('Error with size of wavevector for input pars')
        else:
            alf = var / wvec
            effic, delta, ddsqr, v_dd, v_d = tube_mts(alf)
            delta = delta * reff
            ddsqr = ddsqr * reff ** 2
            v_dd = v_dd * reff ** 2
            v_d = v_d * reff ** 2
    return (effic, delta, ddsqr, v_dd, v_d)

def tube_mts(alf):
    g0 = (32.0 - 3.0 * np.pi ** 2) / 48.0
    g1 = 14.0 / 3.0 - np.pi ** 2 / 8.0
    c_eff_f = [0.7648360390553052, -0.3700950778935237, 0.1582704090813516, -0.06017021866970541, 0.020465515957968954, -0.006269018146570684, 0.001740866718474583, -0.0004410137899942512, 0.00010252117967127217, -2.198890473811166e-05, 4.372934790562999e-06, -8.099875394484979e-07, 1.4031240949230473e-07, -2.281597169861982e-08, 3.4943984983382138e-09, -5.056269680725478e-10, 6.931548335309401e-11, -9.026159819569557e-12, 1.1192324844699896e-12, -1.3204992654891613e-13, 1.4100387524251802e-14, -8.643086246706844e-16, -1.1129985821867194e-16, -4.55052662218236e-16, 3.8885561437496107e-16]
    c_eff_g = [2.033429926215546, -0.023123407369310213, 0.007067191573489487, -0.0007597001753825716, 7.484865254183238e-05, 4.564267918646059e-05, -2.3097291253000307e-05, 1.969722171527577e-06, 2.4115259271262344e-06, -7.130222091933369e-07, -2.512442762159228e-07, 1.324688487513992e-07, 3.436419680591385e-08, -2.2891359549026545e-08, -6.728124021249116e-09, 3.829245861508568e-09, 1.645102103431384e-09, -5.586896212328441e-10, -4.2052310689211226e-10, 4.3217612266666097e-11, 9.954769952802422e-11, 1.2882834243832518e-11, -1.9103066351000564e-11, -7.680549529709425e-12, 1.8568853399347774e-12]
    c_del_f = [1.457564928500728, -0.2741263150129247, 0.014102406058428482, 0.011868136977190956, -0.004700012088869542, 0.0006707100262038035, 0.00012315212155928235, -8.79857483803903e-05, 1.895264475859415e-05, 4.410171164614951e-07, -1.5292393205490472e-06, 4.5050196748941395e-07, -2.997170397533999e-08, -2.3573145628841275e-08, 9.622833634370664e-09, -1.3038786850216867e-09, -2.942346200018875e-10, 1.8813720970012326e-10, -3.7682054143672874e-11, -1.9125961925325894e-12, 3.351614541458048e-12, -9.084241692214334e-13, 4.395178665461685e-14, 4.579392420822615e-14, -1.4916540225229368e-14]
    c_del_g = [1.980495234559052, 0.013148750635418816, -0.0035137830163154958, 0.00014111112411286598, -2.4707009281715874e-05, -4.960202497295008e-08, 1.5268651833078018e-06, -4.807075208312917e-07, -3.5826648758785495e-08, 6.026425348304443e-08, -4.2948016776289676e-09, -7.584017152062472e-09, 1.046815123473266e-09, 1.1267346944343615e-09, -1.4810551229871295e-10, -1.960528772659842e-10, 9.859659755306893e-12, 3.675235449307479e-11, 3.263485037763303e-12, -6.620783921107432e-12, -1.915834157983909e-12, 9.609149587141985e-13, 6.319852974279173e-13, -6.468117708102738e-14, -1.8198241524824965e-13]
    c_xsqr_f = [2.675986138240137, 0.404142909163152, 0.021888771714164857, -0.03431028647221362, 0.009872479091941938, -0.0007726725125629763, -0.0004668141848714702, 0.00020604262514245964, -3.1387761886573216e-05, -5.172896666538751e-06, 3.941756471010915e-06, -8.652250550489348e-07, -1.6220695979729528e-08, 6.854625575480888e-08, -2.0405647520593815e-08, 1.4047699248287414e-09, 1.0523175986154597e-09, -4.342235765397717e-10, 5.964973848193722e-11, 1.301742491577329e-11, -8.460528944098655e-12, 1.70464836690698e-12, 8.2185647176658e-14, -1.4448442442471788e-13, 3.572045437216786e-14]
    c_xsqr_g = [1.723549588238691, 0.136556580101508, 0.002045796217952234, -0.0003987569519500811, 2.394962185583327e-05, -1.6129278268772752e-06, -1.146660950948064e-06, 4.308632219329756e-07, 1.7612995328875058e-09, -4.5839686845239313e-08, 5.995717053952632e-09, 5.320425886523594e-09, -1.1050097059595032e-09, -7.702848098256609e-10, 1.564404439324818e-10, 1.3525529252156333e-10, -1.5409274967126408e-11, -2.605230586816276e-11, -8.378198135261527e-13, 4.8823761700234054e-12, 1.1086589979392159e-12, -7.585165828771778e-13, -4.0599884565395427e-13, 7.997158490979927e-14, 1.3500020545897938e-13]
    c_vx_f = [1.22690458305819, -0.3621914072547197, 0.06011794761774708, 0.018037337764424607, -0.014439005957980124, 0.003814744672451791, 1.3679160269450818e-05, -0.0003785133840135457, 0.00013568342238781005, -1.3336183765173536e-05, -7.546839066303601e-06, 3.791958086930558e-06, -6.456078891925455e-07, -1.05097898972506e-07, 9.028223340812325e-08, -2.1598200223849063e-08, -2.620075012504941e-10, 1.869327004300203e-09, -6.009760084024763e-10, 4.726319668968415e-11, 3.3052446335446465e-11, -1.473809047025654e-11, 2.194517623177461e-12, 4.740904890887521e-13, -3.350247856914734e-13]
    c_vx_g = [1.862646413811875, 0.07598888616980867, -0.008311062038491098, 0.0011236935254690804, -0.00010549380723194779, -3.825667278345324e-05, 2.2883355513325655e-05, -2.459551544851113e-06, -2.2063956882489855e-06, 7.233197029077321e-07, 2.2080170614557914e-07, -1.2957057474505262e-07, -2.9737380539129885e-08, 2.2171316129693253e-08, 5.912700482557654e-09, -3.7179338302495423e-09, -1.4794271269158442e-09, 5.541244824103231e-10, 3.8726354734119895e-10, -4.656241392453353e-11, -9.273452561409101e-11, -1.1246343578630302e-11, 1.6909724176450425e-11, 5.614624598582197e-12, -2.740827495517628e-12]
    c_vy_f = [2.408884004758557, 0.1441097208627301, -0.050093583831079744, 0.010574012517851051, -0.0004724549141870038, -0.0005687475398661623, 0.00022050994176359696, -3.0071128379836053e-05, -6.517527646068277e-06, 4.290862451115096e-06, -8.832778302936273e-07, -3.5778896608773537e-08, 7.616411504818287e-08, -2.139995917360693e-08, 1.159970014485978e-09, 1.2029935880786268e-09, -4.6385151497574384e-10, 5.7945164222417135e-11, 1.572583618880685e-11, -9.195345040957647e-12, 1.744982491835856e-12, 1.230193724666151e-13, -1.6739387653785798e-13, 4.550554377757976e-14, -4.3223757906218904e-15]
    c_vy_g = [1.970558139796674, 0.01987418952478075, -0.005352071931940375, 0.00023885486654173115, -4.142835795158284e-05, -6.322903541811087e-07, 2.8594609307941445e-06, -8.537830532262536e-07, -8.238335822419173e-08, 1.1218202137786016e-07, -6.073665187456001e-09, -1.4453200922748266e-08, 1.7154640064021009e-09, 2.1673530992138977e-09, -2.4074988114186623e-10, -3.767883938188277e-10, 1.1723938486696284e-11, 7.012518288274094e-11, 7.512733213310696e-12, -1.247823733230291e-11, -3.888065980284239e-12, 1.7635456983633446e-12, 1.243944947049158e-12, -9.41950684119064e-14, -3.410581539409208e-13]
    if alf < 0:
        raise ValueError('alf < 0, invalid choice')
    elif alf <= 9.0:
        eff = np.pi / 4.0 * alf * chbmts(0.0, 10.0, c_eff_f, 25, alf)
        delta = -0.125 * alf * chbmts(0.0, 10.0, c_del_f, 25, alf)
        xsqr = 0.25 * chbmts(0.0, 10.0, c_xsqr_f, 25, alf)
        vx = 0.25 * chbmts(0.0, 10.0, c_vx_f, 25, alf)
        vy = 0.25 * chbmts(0.0, 10.0, c_vy_f, 25, alf)
    elif alf >= 10.0:
        y = 1.0 - 18.0 / alf
        eff = 1.0 - chbmts(-1.0, 1.0, c_eff_g, 25, y) / alf ** 2
        delta = (2.0 * chbmts(-1.0, 1.0, c_del_g, 25, y) / alf - 0.25 * np.pi) / eff
        xsqr = (-np.pi / alf * chbmts(-1.0, 1.0, c_xsqr_g, 25, y) + 2.0 / 3.0) / eff
        vx = g0 + g1 * chbmts(-1.0, 1.0, c_vx_g, 25, y) / alf ** 2
        vy = (-chbmts(-1.0, 1.0, c_vy_g, 25, y) / alf ** 2 + 1.0 / 3.0) / eff
    else:
        eff_f = np.pi / 4.0 * alf * chbmts(0.0, 10.0, c_eff_f, 25, alf)
        del_f = -0.125 * alf * chbmts(0.0, 10.0, c_del_f, 25, alf)
        xsqr_f = 0.25 * chbmts(0.0, 10.0, c_xsqr_f, 25, alf)
        vx_f = 0.25 * chbmts(0.0, 10.0, c_vx_f, 25, alf)
        vy_f = 0.25 * chbmts(0.0, 10.0, c_vy_f, 25, alf)
        y = 1.0 - 18.0 / alf
        eff_g = 1.0 - chbmts(-1.0, 1.0, c_eff_g, 25, y) / alf ** 2
        del_g = (2.0 * chbmts(-1.0, 1.0, c_del_g, 25, y) / alf - 0.25 * np.pi) / eff_g
        xsqr_g = (-np.pi / alf * chbmts(-1.0, 1.0, c_xsqr_g, 25, y) + 2.0 / 3.0) / eff_g
        vx_g = g0 + g1 * chbmts(-1.0, 1.0, c_vx_g, 25, y) / alf ** 2
        vy_g = (-chbmts(-1.0, 1.0, c_vy_g, 25, y) / alf ** 2 + 1.0 / 3.0) / eff_g
        eff = (10.0 - alf) * eff_f + (alf - 9.0) * eff_g
        delta = (10.0 - alf) * del_f + (alf - 9.0) * del_g
        xsqr = (10.0 - alf) * xsqr_f + (alf - 9.0) * xsqr_g
        vx = (10.0 - alf) * vx_f + (alf - 9.0) * vx_g
        vy = (10.0 - alf) * vy_f + (alf - 9.0) * vy_g
    return (eff, delta, xsqr, vx, vy)

def chbmts(a, b, c, m, x):
    d = 0.0
    ddd = 0.0
    y = (2.0 * x - a - b) / (b - a)
    for j in range(m - 1, 0, -1):
        sv = d
        d = 2.0 * y * d - ddd + c[j]
        ddd = sv
    out = y * d - ddd + 0.5 * c[0]
    return out

def sam0(sx, sy, sz, isam):
    varx = 0
    vary = sy ** 2 * sample_shape_scaling_factors[isam]
    varz = 0
    return (varx, vary, varz)
sample_shape_scaling_factors = collections.defaultdict(lambda: 1.0 / 12)
sample_shape_scaling_factors[2] = 1.0 / 8