import warnings
import numpy as np
from . import Chop
from scipy.interpolate import interp1d
from scipy.special import erf

def soft_hat(x, p):
    x = np.array(x)
    sig2fwhh = np.sqrt(8 * np.log(2))
    height, grad, x1, x2 = tuple(p[:4])
    sig1, sig2 = tuple(np.abs(p[4:6] / sig2fwhh))
    sig = ((x2 - x) * sig1 - (x1 - x) * sig2) / (x2 - x1)
    if np.shape(sig):
        sig[x < x1] = sig1
        sig[x > x2] = sig2
    e1 = (x1 - x) / (np.sqrt(2) * sig)
    e2 = (x2 - x) / (np.sqrt(2) * sig)
    y = (erf(e2) - erf(e1)) * ((height + grad * (x - (x2 + x1) / 2)) / 2)
    y = y + 1
    return y

class ISISFermi:
    __Instruments = {'MAPS': [10.1, 8.27, 1.9, 6.0, 0.094, 0.094, 0.0, 2, 0.025, 0.0], 'MARI': [10.05, 7.19, 1.689, 4.022, 0.06667, 0.06667, 0.0, 2, 0.025, 0.0], 'MERLIN': [10.0, 7.19, 1.82, 2.5, 0.06667, 0.06667, 0.0, 2, 0.025, 0.0]}
    __samplesDimensions = {'MAPS': [2.0, 48.0, 48.0, 0], 'MARI': [20.0, 19.0, 50.0, 2], 'MERLIN': [2.0, 40.0, 40.0, 0]}
    __chopperParameters = {'MARI': {'A': {'par': [0.76, 0.55, 49.0, 1300.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MARI A (500meV)'}, 'B': {'par': [1.14, 0.55, 49.0, 820.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MARI B (200meV)'}, 'C': {'par': [1.52, 0.55, 49.0, 580.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MARI B (100meV)'}, 'G': {'par': [0.38, 0.02, 10.0, 800.0, 0.0, 0.0], 'fluxcorr': 3.2, 'title': 'MARI G (Gadolinium)'}, 'R': {'par': [1.143, 0.55, 49.0, 1300.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MARI R (500meV)'}, 'S': {'par': [2.28, 0.55, 49.0, 1300.0, 0.0, 0.0], 'fluxcorr': 2.7, 'title': 'MARI S (Sloppy)'}}, 'MAPS': {'A': {'par': [1.087, 0.534, 49.0, 1300.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MAPS A (500meV)'}, 'B': {'par': [1.812, 0.534, 49.0, 920.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MAPS B (200meV)'}, 'S': {'par': [2.899, 0.534, 49.0, 1300.0, 0.0, 0.0], 'fluxcorr': 2.5, 'title': 'MAPS S (Sloppy)'}}, 'MERLIN': {'S': {'par': [2.28, 0.55, 49.0, 1300.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'HET S (Sloppy)'}, 'G': {'par': [0.2, 0.02, 5.0, 1000000.0, 0.0, 0.0], 'fluxcorr': 3.0, 'title': 'MERLIN G (Gadolinium)'}}}
    __Moderators = {'MAPS': {'imod': 2, 'ch_mod': 'AP', 'mod_pars': [38.6, 0.5226], 'mod_scale_fn': soft_hat, 'mod_scale_par': [1.0, 0.0, 0.0, 150.0, 0.01, 70.0], 'theta': 32.0}, 'MARI': {'imod': 2, 'ch_mod': 'CH4', 'mod_pars': [38.6, 0.5226], 'mod_scale_fn': None, 'theta': 13.0}, 'MERLIN': {'imod': 2, 'ch_mod': 'AP', 'mod_pars': [80.0, 0.5226], 'mod_scale_fn': None, 'theta': 26.7}}
    __DiskChopperMode = {'MERLIN': 1500, 'MAPS': 0, 'MARI': 2}

    def __init__(self, instname=None, choppername='', freq=0):
        warnings.warn('The ISISFermi class is deprecated and will be removed in the next Mantid version. Please use the Instrument class or the official PyChop CLI interface.', DeprecationWarning)
        if instname:
            self.setInstrument(instname, choppername, freq)
            self.diskchopper_phase = self.__DiskChopperMode[instname]
        else:
            self.instname = None
            self.diskchopper_phase = None
        self.Ei = None

    def setInstrument(self, instname, choppername='', freq=0):
        instname = instname.upper()
        if instname not in self.__Instruments.keys():
            raise ValueError('Instrument %s not recognised' % instname)
        self.instname = instname
        if choppername:
            self.setChopper(choppername, freq)

    def setChopper(self, choppername, freq=50, diskchopper_phase=None, diskchopper_freq=None):
        choppername = choppername.upper()
        if choppername not in self.__chopperParameters[self.instname].keys():
            raise ValueError('Chopper %s of %s not recognised' % (choppername, self.instname))
        self.choppername = choppername
        self.freq = freq if np.shape(freq) else [freq]
        if self.freq[0] % 50 != 0:
            raise ValueError('Chopper frequency must be a multiple of 50Hz')
        if self.freq[0] <= 0:
            raise ValueError('Chopper frequency must be greater than 0Hz')
        if diskchopper_phase is not None:
            self.diskchopper_phase = diskchopper_phase

    def getChopper(self):
        return self.choppername

    def setFrequency(self, frequency, **kwargs):
        if 'Chopper2Phase' in kwargs.keys():
            diskchopper_phase = kwargs['Chopper2Phase']
        elif 'diskchopper_phase' in kwargs.keys():
            diskchopper_phase = kwargs['diskchopper_phase']
        else:
            diskchopper_phase = None
        self.setChopper(self.choppername, frequency, diskchopper_phase)

    def getFrequency(self):
        return self.freq

    def setEi(self, Ei):
        self.Ei = Ei

    def getEi(self):
        return self.Ei

    def getChopWidth(self, Ei_in=None):
        Ei = self.Ei if Ei_in is None else Ei_in
        if not Ei:
            raise ValueError('Incident energy has not be specified')
        chop_par = self.__chopperParameters[self.instname][self.choppername]['par']
        pslit = chop_par[0] / 1000.0
        radius = chop_par[2] / 1000.0
        rho = chop_par[3] / 1000.0
        return Chop.tchop(self.freq[0], Ei, pslit, radius, rho)

    def getModWidth(self, Ei_in=None):
        Ei = self.Ei if Ei_in is None else Ei_in
        if not Ei:
            raise ValueError('Incident energy has not been specified')
        if self.__Moderators[self.instname]['imod'] == 0:
            tsqmod = Chop.tchi(self.__Moderators[self.instname]['mod_pars'] / 1000.0, Ei)
        elif self.__Moderators[self.instname]['imod'] == 1:
            tsqmod = Chop.tikeda(tuple(self.__Moderators[self.instname]['mod_pars']), Ei)
        elif self.__Moderators[self.instname]['imod'] == 2:
            if self.__Moderators[self.instname]['mod_scale_fn']:
                d0 = self.__Moderators[self.instname]['mod_scale_fn'](Ei, self.__Moderators[self.instname]['mod_scale_par'])
                d0 *= self.__Moderators[self.instname]['mod_pars'][0]
            else:
                d0 = self.__Moderators[self.instname]['mod_pars'][0]
            tsqmod = Chop.tchi_2(d0 / 1000.0, self.__Moderators[self.instname]['mod_pars'][1] / 1000.0, Ei)
        else:
            raise RuntimeError('PyChop: Bug in instrument-moderator database. Please file a bug report')
        return tsqmod

    def getVanVar(self, Ei_in=None, frequency=None, Etrans=0):
        Ei = self.Ei if Ei_in is None else Ei_in
        if not Ei:
            raise ValueError('Incident energy has not been specified')
        if frequency:
            oldfreq = self.freq
            self.setFrequency(frequency)
        tsqmod = self.getModWidth(Ei)
        tsqchp = self.getChopWidth(Ei)
        omega = self.freq[0] * 2 * np.pi
        tsqjit = (self.__chopperParameters[self.instname][self.choppername]['par'][5] * 1e-06) ** 2
        sam_dims = np.array(self.__samplesDimensions[self.instname])
        sam_dims[:2] /= 1000
        v_x, v_y, v_z = Chop.sam0(*list(sam_dims))
        v_xy = 0.0
        phi = 0.0
        v_van = []
        if not np.shape(Etrans):
            Etrans = [Etrans]
        for en in Etrans:
            omega_f = 0.69468875 * np.sqrt(Ei - en)
            deld, sigd, sigdz, sigdd, effic = Chop.detect2(1.0, 1.0, omega_f, *self.__Instruments[self.instname][7:9])
            v_dd = sigdd ** 2
            v_van.append(self.__van_calc(tsqmod, tsqchp, tsqjit, v_x, v_y, v_xy, v_dd, Ei, en, phi, omega))
        if frequency:
            self.setFrequency(oldfreq)
        r = 1
        x0 = self.__Instruments[self.instname][0]
        x1 = self.__Instruments[self.instname][2]
        x2 = self.__Instruments[self.instname][3]
        tmod = np.sqrt(((x1 + r * x2) / x0) ** 2 * tsqmod)
        tchp = np.sqrt((1 + (x1 + r * x2) / x0) ** 2 * tsqchp)
        return (v_van, tmod, tchp)

    def getWidths(self, Ei_in=None, frequency=None):
        Ei = self.Ei if Ei_in is None else Ei_in
        if not Ei:
            raise ValueError('Incident energy has not been specified')
        v_van, tmod, tchp = self.getVanVar(Ei, frequency, 0.0)
        x2 = self.__Instruments[self.instname][3]
        tbin = self.__Instruments[self.instname][9]
        res_el = np.real(2.35482 * 0.0008747832 * np.sqrt(Ei ** 3) * (np.sqrt(v_van[0] + tbin ** 2 / 12.0) * 1000000.0) / x2)
        return {'Moderator': tmod * 2354820.0, 'Chopper': tchp * 2354820.0, 'Energy': res_el}

    def __van_calc(self, v_mod, v_ch, v_jit, v_x, v_y, v_xy, v_dd, Ei, eps, phi, omega):
        x0, xa, x1, x2, wa, ha, gam_deg = tuple(self.__Instruments[self.instname][:7])
        thetam = self.__Moderators[self.instname]['theta'] * (np.pi / 180.0)
        gam = gam_deg * (np.pi / 180.0)
        veli = 437.3916 * np.sqrt(Ei)
        velf = 437.3916 * np.sqrt(Ei - np.array(eps))
        rat = (veli / velf) ** 3
        tanthm = np.tan(thetam)
        am = -(x1 + rat * x2) / x0
        ach = 1.0 + (x1 + rat * x2) / x0
        g1 = 1.0 - omega * (xa + x1) * tanthm / veli
        g2 = 1.0 - omega * (x0 - xa) * tanthm / veli
        f1 = 1.0 + x1 / x0 * g1
        f2 = 1.0 + x1 / x0 * g2
        gg1 = g1 / (omega * (xa + x1))
        gg2 = g2 / (omega * (xa + x1))
        ff1 = f1 / (omega * (xa + x1))
        ff2 = f2 / (omega * (xa + x1))
        bb = -np.sin(gam) / veli + np.sin(gam - phi) / velf - ff2 * np.cos(gam)
        aya = ff1 + rat * x2 / x0 * gg1
        ay = bb - rat * x2 / x0 * gg2 * np.cos(gam)
        a_dd = 1.0 / velf
        v_van_m = am ** 2 * v_mod
        v_van_ch = ach ** 2 * v_ch
        v_van_jit = ach ** 2 * v_jit
        v_van_ya = aya ** 2 * (wa ** 2 / 12.0)
        v_van_y = ay ** 2 * v_y
        v_van_dd = a_dd ** 2 * v_dd
        v_van = v_van_m + v_van_ch + v_van_jit + v_van_ya + v_van_y + v_van_dd
        return v_van

    def getResolution(self, Etrans=None, Ei_in=None, frequency=None):
        Ei = self.Ei if Ei_in is None else Ei_in
        if not Ei:
            raise ValueError('Incident energy has not been specified')
        if frequency:
            oldfreq = self.freq
            self.setFrequency(frequency)
        if Etrans is None:
            Etrans = Ei - np.linspace(0.05 * Ei, 0.95 * Ei + 0.05 * 0.05 * Ei, 19, endpoint=True)
        convert = 2.35482
        x2 = self.__Instruments[self.instname][3]
        tbin = self.__Instruments[self.instname][9]
        v_van, tsqmod, tsqchop = self.getVanVar(Ei, frequency, Etrans)
        if not np.shape(Etrans):
            Etrans = [Etrans]
        van = []
        for ie, en in enumerate(Etrans):
            van.append(np.real(convert * 0.0008747832 * np.sqrt((Ei - en) ** 3) * (np.sqrt(v_van[ie] + tbin ** 2 / 12.0) * 1000000.0) / x2))
        if frequency:
            self.setFrequency(oldfreq)
        return np.array(van)

    def getFlux(self, Ei_in=None, frequency=None):
        Ei = self.Ei if Ei_in is None else Ei_in
        if Ei is None:
            raise ValueError('Incident energy has not been specified')
        if frequency:
            oldfreq = self.freq
            self.setFrequency(frequency)
        moderator_flux = self.getMeasuredFlux(Ei)
        chop_par = self.__chopperParameters[self.instname][self.choppername]['par']
        pslit = chop_par[0] / 1000.0
        dslat = (chop_par[0] + chop_par[1]) / 1000.0
        radius = chop_par[2] / 1000.0
        rho = chop_par[3] / 1000.0
        chopper_transmission = Chop.achop(Ei, self.freq[0], dslat, pslit, radius, rho)
        x0 = self.__Instruments[self.instname][0]
        x1 = self.__Instruments[self.instname][2]
        flux = 84403.06 * moderator_flux * (chopper_transmission / dslat) / (x0 * (x1 + x0))
        flux /= self.__chopperParameters[self.instname][self.choppername]['fluxcorr']
        if frequency:
            self.setFrequency(oldfreq)
        return flux

    def getResFlux(self, Etrans=None, Ei_in=None, frequency=None):
        return (self.getResolution(Etrans, Ei_in, frequency), self.getFlux(Ei_in, frequency))

    def getResFluxRAE(self, Etrans=None, Ei_in=None, frequency=None):
        van_el = self.getResolution(0.0, Ei_in, frequency)
        van = self.getResolution(Etrans, Ei_in, frequency)
        flux = self.getFlux(Ei_in, frequency)
        van_vars = self.getVanVar(Ei_in)
        return (van_el, van, flux, van_vars[1], van_vars[2], van_vars[0][0])

    def getAnalyticFlux(self, Ei):
        ch_mod = self.__Moderators[self.instname]['ch_mod']
        theta_m = self.__Moderators[self.instname]['theta'] * np.pi / 180.0
        return Chop.flux_calc(Ei, ch_mod, theta_m)

    def getMeasuredFlux(self, Ei_in=None):
        Ei = self.Ei if Ei_in is None else Ei_in
        if Ei is None:
            raise ValueError('Incident energy has not be specified')
        lam, flux_meas = self.flux_store()
        f = interp1d(lam, flux_meas, kind='cubic')
        lamb = np.sqrt(81.81 / Ei)
        return f(lamb)

    def flux_store(self):
        lam = [0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95, 1.05, 1.15, 1.25, 1.35, 1.45, 1.55, 1.65, 1.75, 1.85, 1.95, 2.05, 2.15, 2.25, 2.35, 2.45, 2.55, 2.65, 2.75, 2.85, 2.95, 3.05, 3.15, 3.25, 3.35, 3.45, 3.55, 3.65, 3.75, 3.85, 3.95, 4.05, 4.15, 4.25, 4.35, 4.45, 4.55, 4.65, 4.75, 4.85, 4.95, 5.05, 5.15, 5.25, 5.35, 5.45, 5.55, 5.65, 5.75, 5.85, 5.95, 6.05, 6.15, 6.25, 6.35, 6.45, 6.55, 6.65, 6.75, 6.85, 6.95, 7.05, 7.15, 7.25, 7.35, 7.45, 7.55, 7.65, 7.75, 7.85, 7.95, 8.05, 8.15, 8.25, 8.35, 8.45, 8.55, 8.65, 8.75, 8.85, 8.95, 9.05, 9.15, 9.25, 9.35, 9.45, 9.55, 9.65, 9.75, 9.85, 9.95, 10.05]
        lamb = {'MAPS': [0.0181, 0.0511, 0.0841, 0.117, 0.15, 0.1829, 0.2159, 0.2489, 0.2818, 0.3148, 0.3477, 0.3807, 0.4137, 0.4466, 0.4796, 0.5126, 0.5455, 0.5785, 0.6114, 0.6444, 0.6774, 0.7103, 0.7433, 0.7762, 0.8092, 0.8422, 0.8751, 0.9081, 0.9411, 0.974, 1.007, 1.0399, 1.0729, 1.1059, 1.1388, 1.1718, 1.2047, 1.2377, 1.2707, 1.3036, 1.3366, 1.3696, 1.4025, 1.4355, 1.4684, 1.5014, 1.5344, 1.5673, 1.6003, 1.6332, 1.6662, 1.6992, 1.7321, 1.7651, 1.798, 1.831, 1.864, 1.8969, 1.9299, 1.9629, 1.9958, 2.0288, 2.0617, 2.0947, 2.1277, 2.1606, 2.1936, 2.2266, 2.2595, 2.2925, 2.3254, 2.3584, 2.3914, 2.4243, 2.4573, 2.4902, 2.5232, 2.5562, 2.5891, 2.6221, 2.6551, 2.688, 2.721, 2.7539, 2.7869, 2.8199, 2.8528, 2.8858, 2.9187, 2.9517, 2.9847, 3.0176, 3.0506, 3.0835, 3.1165, 3.1495, 3.1824, 3.2154, 3.2484, 3.2813, 3.3143, 3.3472, 3.3802, 3.4132, 3.4461, 3.4791, 3.512, 3.545, 3.578, 3.6109, 3.6439, 3.6769, 3.7098, 3.7428, 3.7757, 3.8087, 3.8417, 3.8746, 3.9076, 3.9406, 3.9735, 4.0065, 4.0394, 4.0724, 4.1054, 4.1383, 4.1713, 4.2042, 4.2372, 4.2702, 4.3031, 4.3361, 4.369, 4.402, 4.435, 4.4679, 4.5009, 4.5339, 4.5668, 4.5998, 4.6327, 4.6657, 4.6987, 4.7316, 4.7646, 4.7976, 4.8305, 4.8635, 4.8964, 4.9294, 4.9624, 4.9953, 5.0283, 5.0612, 5.0942, 5.1272, 5.1601, 5.1931, 5.226, 5.259, 5.292, 5.3249, 5.3579, 5.3909, 5.4238, 5.4568, 5.4897, 5.5227, 5.5557, 5.5886, 5.6216, 5.6546, 5.6875, 5.7205, 5.7534, 5.7864, 5.8194, 5.8523, 5.8853, 5.9182, 5.9512, 5.9842, 6.0171, 6.0501, 6.0831, 6.116, 6.149, 6.1819, 6.2149, 6.2479, 6.2808, 6.3138, 6.3467, 6.3797, 6.4127, 6.4456, 6.4786, 6.5115, 6.5445, 6.575], 'MARI': lam, 'MERLIN': lam}
        flux = {'MAPS': [260775000.0, 80861600.0, 45945500.0, 31618300.0, 23783000.0, 19145800.0, 15820400.0, 13608800.0, 11922500.0, 10610500.0, 9555330.0, 8774110.0, 8219010.0, 7676560.0, 7150550.0, 6707570.0, 6392760.0, 6228260.0, 6197980.0, 6277310.0, 6479940.0, 6916040.0, 7505730.0, 8090350.0, 8768750.0, 9499750.0, 10165800.0, 10754800.0, 11359700.0, 11994100.0, 12537400.0, 12882100.0, 13124800.0, 13272700.0, 13230500.0, 13083400.0, 12759500.0, 12435100.0, 12011500.0, 11578900.0, 11121800.0, 10719100.0, 10327200.0, 9938560.0, 9593760.0, 9198360.0, 8815710.0, 8504570.0, 8292740.0, 8050580.0, 7884370.0, 7639070.0, 7320470.0, 6996810.0, 6689680.0, 6452700.0, 6241610.0, 6013230.0, 5747130.0, 5488160.0, 5271530.0, 5017800.0, 4761270.0, 4481720.0, 4213450.0, 3970930.0, 3748190.0, 3536830.0, 3329350.0, 3124040.0, 2928010.0, 2744790.0, 2616340.0, 2486060.0, 2388260.0, 2294100.0, 2176360.0, 2074610.0, 1970630.0, 1872200.0, 1777800.0, 1702020.0, 1625840.0, 1557630.0, 1489890.0, 1429240.0, 1379590.0, 1340560.0, 1319260.0, 1285730.0, 1255590.0, 1224260.0, 1189880.0, 1157140.0, 1130320.0, 1094230.0, 1061610.0, 1026500.0, 995519.0, 956437.0, 924815.0, 890446.0, 856656.0, 828196.0, 801094.0, 779358.0, 756306.0, 735949.0, 724375.0, 702174.0, 686458.0, 665894.0, 643176.0, 624539.0, 601304.0, 582505.0, 561653.0, 541996.0, 525903.0, 510613.0, 496677.0, 482118.0, 464661.0, 465809.0, 468617.0, 456137.0, 442141.0, 427460.0, 410041.0, 398628.0, 384161.0, 371166.0, 357501.0, 345980.0, 335925.0, 323733.0, 313815.0, 303413.0, 291757.0, 282348.0, 272917.0, 257271.0, 241863.0, 258619.0, 253316.0, 243464.0, 235779.0, 229787.0, 222481.0, 214144.0, 208181.0, 201866.0, 195864.0, 189808.0, 184740.0, 178016.0, 173397.0, 168777.0, 165549.0, 161071.0, 156594.0, 152364.0, 149546.0, 146162.0, 143155.0, 140167.0, 137583.0, 135294.0, 132192.0, 130639.0, 127633.0, 125179.0, 123187.0, 121203.0, 118074.0, 115095.0, 112187.0, 110561.0, 108411.0, 105109.0, 103695.0, 101165.0, 98779.7, 97784.1, 94076.8, 92735.3, 91493.7, 88828.9, 87435.3, 85325.1, 83033.9, 82224.9, 79409.9, 77903.7, 76286.5, 74704.7, 73853.5, 71722.8, 69892.7, 68950.9], 'MARI': [4293800.0, 5706100.0, 5798400.0, 4996400.0, 3879600.0, 3147400.0, 2437500.0, 1936100.0, 1610400.0, 1459000.0, 1376700.0, 1370600.0, 1400500.0, 1426300.0, 1411700.0, 1387900.0, 1332300.0, 1269900.0, 1175700.0, 1068000.0, 955870.0, 855490.0, 741730.0, 690010.0, 628890.0, 548290.0, 484200.0, 428340.0, 386040.0, 340060.0, 297440.0, 263640.0, 229800.0, 201050.0, 176400.0, 155830.0, 137320.0, 121050.0, 105990.0, 96490.0, 88906.0, 79308.0, 71857.0, 65562.0, 59023.0, 50767.0, 50665.0, 45641.0, 41721.0, 36969.0, 33218.0, 30231.0, 27621.0, 25398.0, 21588.0, 12268.0, 3585.5, 209.85, 310.64, 404.48, 489.34, 485.58, 1177.6, 29.689, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 'MERLIN': [34827000.0, 19455000.0, 13618000.0, 10922000.0, 9107400.0, 8994900.0, 10717000.0, 14113000.0, 17890000.0, 20977000.0, 22164000.0, 21097000.0, 19449000.0, 17522000.0, 15395000.0, 13518000.0, 11794000.0, 10664000.0, 9413400.0, 7868800.0, 6788100.0, 5942800.0, 4923800.0, 4221900.0, 3843200.0, 3360600.0, 2929900.0, 2611000.0, 2333500.0, 2056300.0, 1800500.0, 1600200.0, 1449000.0, 1336800.0, 1259900.0, 1123900.0, 1052400.0, 972660.0, 862180.0, 766810.0, 700490.0, 678220.0, 629930.0, 625710.0, 586080.0, 536860.0, 553090.0, 522450.0, 483650.0, 443840.0, 394450.0, 371990.0, 328120.0, 311620.0, 293010.0, 267040.0, 263960.0, 246350.0, 219400.0, 211460.0, 201270.0, 194120.0, 179080.0, 179020.0, 163320.0, 117460.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}
        return (lamb[self.instname], flux[self.instname])