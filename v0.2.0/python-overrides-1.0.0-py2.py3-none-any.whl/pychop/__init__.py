def PyChop2(*args, **kwargs):
    import warnings
    warnings.warn("Deprecation Warning: Importing 'PyChop2' from the 'mantidqtinterfaces.PyChop' module is deprecated.Please import 'Instrument' from the 'pychop.Instruments' module instead.", DeprecationWarning)
    from pychop.Instruments import Instrument
    return Instrument(*args, **kwargs)