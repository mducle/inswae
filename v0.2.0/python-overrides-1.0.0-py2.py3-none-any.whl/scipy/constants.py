m_n = 1.67492749804e-27
neutron_mass = 1.67492749804e-27
hbar = 1.0545718176461565e-34
e = 1.602176634e-19
elementary_charge = 1.602176634e-19
h = 6.62607015e-34
k = 1.380649e-23
Boltzmann = 1.380649e-23
full_dict = {'Boltzmann constant in eV/K': 8.617333262e-05}

def value(name):
    if name in full_dict.keys():
        return full_dict[name]
    else:
        return globals()[name]