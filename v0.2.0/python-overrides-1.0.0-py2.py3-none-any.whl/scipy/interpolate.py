import numpy as np

def interp1d(xp, yp, **kwargs):
    return lambda x: np.interp(x, xp, yp)